package com.hoingmarry.travelchat.utils;

public interface Unregistrar {
    void unregister();
}
