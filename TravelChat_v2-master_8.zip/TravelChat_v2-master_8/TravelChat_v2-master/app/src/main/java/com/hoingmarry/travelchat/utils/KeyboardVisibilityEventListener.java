package com.hoingmarry.travelchat.utils;

public interface KeyboardVisibilityEventListener {
    void onVisibilityChanged(boolean var1);
}
